# HCA Innovations

## Install packages via bower

``` bash
bower install <package>
```

# Please install editorconfig for code consistency
If you are using Sumblime ctrl+cmd+p >package control:install package> EditorConfig

## Dev Notes

- Cards with card list and card grid views need reactoring

